# Introduction to Threat Hunting & Hunting With Elastic

# Threat Hunting Fundamentals

## Threat Hunting Definition

- Khoảng thời gian trung bình từ khi hệ thống bị xâm nhập đến khi bị phát hiện được gọi là **dwell time**, thường kéo dài từ vài tuần đến vài tháng.
- Mục tiêu cốt lõi của quy trình Threat Hunting là giảm thiểu **dwell time** bằng cách phát hiện các mối đe dọa từ giai đoạn sớm của **cyber kill chain**, ngăn chặn kẻ tấn công bám rễ vào hạ tầng.
- Bản chất của hoạt động này là một quá trình chủ động, do con người dẫn dắt và vận hành dựa trên giả thuyết (**hypothesis-driven**) nhằm săn lùng các mối đe dọa tinh vi lọt qua được hệ thống bảo mật tự động.
- Quy trình cơ bản luôn bắt đầu bằng việc xác định tài sản giá trị cao, tiếp nối bằng việc phân tích **TTPs (Tactics, Techniques, and Procedures)** của kẻ tấn công để chủ động phát hiện và cô lập các dấu hiệu bất thường so với baseline tiêu chuẩn.
- Các chuyên gia luôn tận dụng **Threat Intelligence** như một thành phần thiết yếu để xây dựng giả thuyết, chiến thuật phản công và biện pháp phòng ngừa.
- Người thực hiện đòi hỏi phải có **cognitive empathy** với kẻ tấn công để thấu hiểu mindset của chúng, đồng thời am hiểu sâu sắc về sơ đồ mạng và tài sản số của tổ chức.
- Hoạt động này bắt buộc phải sử dụng nguồn dữ liệu có độ tin cậy cao kết hợp cùng các nền tảng phân tích chiến thuật tiên tiến.

## The Relationship Between Incident Handling & Threat Hunting

- Giai đoạn **Preparation Phase** yêu cầu thiết lập **Rules of Engagement** rõ ràng để quyết định việc xây dựng quy trình vận hành độc lập hay tích hợp trực tiếp vào chính sách xử lý sự cố hiện tại.
- Trong giai đoạn **Detection & Analysis Phase**, đội ngũ săn lùng sẽ sử dụng tư duy tấn công để hỗ trợ xác minh các **Indicators of Compromise (IoCs)** và phát hiện những artifact có thể đã bị bỏ sót.
- Tại bước **Containment, Eradication, & Recovery Phase**, các thành viên có thể trực tiếp tham gia xử lý sự cố hoặc tiếp tục giám sát bề mặt mạng tùy thuộc vào quy định nội bộ của từng tổ chức.
- Đến giai đoạn **Post-Incident Activity Phase**, các chuyên gia sẽ đóng góp chuyên môn kỹ thuật để đề xuất cải tiến và củng cố toàn diện **security posture** của hệ thống.
- Việc quyết định gộp chung hay tách biệt hai quy trình này phụ thuộc hoàn toàn vào bối cảnh rủi ro và nguồn lực đặc thù của mỗi tổ chức.

## A Threat Hunting Team's Structure

### Core & Analytical Roles

- Lực lượng nòng cốt của đội là các **Threat Hunter** am hiểu sâu sắc về **TTPs** và chủ động săn tìm **IoCs** thông qua các nền tảng chuyên dụng.
- Nhiệm vụ thu thập tình báo từ các nguồn mã nguồn mở hoặc dark web để dự báo xu hướng tấn công được đảm nhận bởi **Threat Intelligence Analyst**.
- Việc xử lý các tập dữ liệu khổng lồ bằng mô hình thống kê và Machine Learning để tìm ra các mẫu ẩn là trách nhiệm của **Data Analysts/Scientists**.

### Response & Forensics Roles

- Lực lượng **Incident Responders** sẽ ngay lập tức tiếp quản khi phát hiện mối đe dọa nhằm điều tra, ngăn chặn, diệt trừ và phục hồi hệ thống.
- Các chuyên gia **Forensics Experts** chuyên sâu về **DFIR (Digital Forensics and Incident Response)** sẽ trực tiếp phân tích phần mềm độc hại, dịch ngược mã và lập báo cáo kỹ thuật chi tiết.

### Engineering & Management Roles

- Toàn bộ hạ tầng bảo mật và các công cụ hỗ trợ phòng thủ theo kill-chain đều được thiết kế và vận hành bởi **Security Engineers/Architects**.
- Việc giám sát hành vi và phát hiện nhanh chóng các điểm dị thường trong lưu lượng mạng thuộc về chuyên môn của **Network Security Analyst**.
- Trách nhiệm giám sát vận hành, điều phối thành viên và đảm bảo luồng giao tiếp thông suốt trong trung tâm điều hành an ninh thuộc về **SOC Manager**.

## When Should We Hunt?

- Chiến dịch săn lùng cần được kích hoạt ngay khi xuất hiện **thông tin tình báo mới** về một nhóm tấn công hoặc các lỗ hổng liên quan trực tiếp đến hệ thống đang sử dụng.
- Đội ngũ bảo mật phải hành động khi có **IoCs mới** thuộc về các nhóm APT có lịch sử nhắm vào tổ chức hoặc các mục tiêu tương đồng trong cùng ngành.
- Việc xuất hiện **nhiều điểm bất thường liên tiếp** trong lưu lượng mạng là tín hiệu rõ ràng cảnh báo một cuộc tấn công có tổ chức cần được điều tra ngay lập tức.
- Quá trình săn lùng luôn phải được thực hiện song song với **hoạt động phản ứng sự cố (IR)** nhằm xác định toàn bộ phạm vi lây nhiễm và các mối đe dọa đang ẩn nấp.
- Tổ chức cần duy trì các đợt **săn lùng định kỳ và liên tục** để chủ động phát hiện các rủi ro tiềm ẩn lọt qua màng lọc bảo mật tiêu chuẩn.

## The Relationship Between Risk Assessment & Threat Hunting

- Quy trình **Risk Assessment** cung cấp cái nhìn toàn cảnh về các vector tấn công nhằm giúp tổ chức phân bổ nỗ lực hunting vào những khu vực trọng yếu nhất.
- Dữ liệu đánh giá rủi ro giúp định hướng nguồn lực bảo mật vào các tài sản quan trọng nhất hay còn gọi là **crown jewels** của hệ thống.
- Đội ngũ bảo mật tận dụng kết quả đánh giá để nắm bắt **TTPs** của kẻ tấn công, tạo tiền đề vững chắc cho việc xây dựng các giả thuyết hunting chính xác.
- Các điểm yếu đã biết trên ứng dụng sẽ được sử dụng làm manh mối để hướng cuộc săn lùng vào việc tìm kiếm dấu hiệu leo thang đặc quyền hoặc khai thác lỗi.
- Việc đánh giá rủi ro còn giúp xác định chính xác nhóm tác nhân đe dọa có khả năng tấn công cao nhất để áp dụng **Threat Intelligence** một cách hiệu quả.
- Kết quả phân tích rủi ro đóng vai trò xương sống trong việc cải thiện kế hoạch phản ứng sự cố (**IR plans**) và nâng cấp các biện pháp kiểm soát an ninh mạng.
- Hoạt động săn lùng thường được tối ưu hóa bằng cách kết hợp với các nền tảng quét lỗ hổng và hệ thống **SIEM (Security Information and Event Management)** để tương quan sự kiện tập trung.

# The Threat Hunting Process

- Giai đoạn chuẩn bị ban đầu **Setting the Stage** đòi hỏi việc kích hoạt hệ thống ghi nhật ký toàn diện trên các công cụ **SIEM**, **EDR**, **IDS** và phân tích kỹ lưỡng các báo cáo tình báo để nắm bắt **TTPs** của kẻ tấn công nhằm xác định chính xác các tài sản trọng yếu cần bảo vệ.
- Bước tiếp theo là **Formulating Hypotheses** bằng cách xây dựng các giả thuyết mang tính thực tiễn và có thể kiểm chứng được dựa trên thông tin tình báo, cảnh báo bảo mật hoặc kinh nghiệm chuyên môn để định hướng khu vực cần rà soát.
- Trong giai đoạn **Designing the Hunt**, đội ngũ bảo mật sẽ khoanh vùng các nguồn dữ liệu cần thiết, xây dựng các truy vấn tùy chỉnh và lập bản đồ các **IoC** cụ thể cần săn lùng.
- Hoạt động **Data Gathering and Examination** diễn ra thông qua việc thu thập và phân tích liên tục các tệp nhật ký, lưu lượng mạng và dữ liệu điểm cuối bằng các phương pháp thống kê hoặc phân tích hành vi nhằm tìm kiếm bằng chứng xác thực hoặc bác bỏ giả thuyết ban đầu.
- Ở bước **Evaluating Findings**, các chuyên gia sẽ diễn giải kết quả phân tích để xác nhận mối đe dọa, phân tích hành vi lây nhiễm và xác định toàn bộ phạm vi ảnh hưởng đối với hệ thống mạng.
- Khi một cuộc tấn công được xác nhận, quy trình **Mitigating Threats** sẽ lập tức kích hoạt các biện pháp cô lập hệ thống bị ảnh hưởng, diệt trừ phần mềm độc hại, vá các lỗ hổng và tinh chỉnh lại cấu hình an ninh.
- Giai đoạn **After the Hunt** yêu cầu phải tài liệu hóa toàn bộ quá trình, cập nhật các **IoCs** mới phát hiện vào nền tảng tình báo và tối ưu hóa lại các **incident response playbooks**.
- Bản chất của hoạt động săn lùng là một chu trình **Continuous Learning and Enhancement**, liên tục tinh chỉnh các công cụ, thuật toán học máy và phương pháp luận dựa trên những bài học kinh nghiệm và bối cảnh rủi ro luôn biến đổi.

# Threat Hunting Glossary

## Threat Actors & Core Concepts

- Một **Adversary** trong **Cyber Threat Intelligence (CTI)** là một thực thể không được phép tìm cách xâm nhập vào hạ tầng để trục lợi tài chính, đánh cắp thông tin nội bộ hoặc tài sản trí tuệ.
- Các tác nhân đe dọa này được phân loại thành nhiều nhóm đặc thù như tội phạm mạng, mối đe dọa nội gián, hacktivists hoặc các toán gián điệp do chính phủ tài trợ.
- Khái niệm **Advanced Persistent Threat (APT)** thường chỉ các nhóm có tổ chức cao, được hậu thuẫn nguồn lực khổng lồ để duy trì chiến dịch bám trụ lâu dài nhằm vào các mục tiêu giá trị cao như chính phủ, y tế hay quốc phòng.
- Yếu tố "Advanced" trong **APT** không nhất thiết là sử dụng kỹ thuật phức tạp mà ám chỉ chiến lược lập kế hoạch tinh vi, trong khi "Persistent" thể hiện sự kiên trì bám trụ nhờ tiềm lực mạnh mẽ về tài chính và nhân sự.
- Một **Campaign** là tập hợp các sự cố bảo mật có chung phương thức tấn công và mục tiêu thu thập, đòi hỏi đội ngũ phòng thủ nhiều thời gian và công sức để đối chiếu dữ liệu.
- Khái niệm **Threat** được cấu thành từ ba yếu tố cốt lõi: **intent** (động cơ tấn công), **capability** (năng lực kỹ thuật, công cụ, tài chính) và **opportunity** (cơ hội hoặc lỗ hổng thuận lợi để khai thác).

![image.png](image.png)

## Tactics, Techniques, and Procedures (TTPs)

- Thuật ngữ **TTPs** đại diện cho các mẫu hoạt động đặc trưng, đóng vai trò như "chữ ký" chiến dịch của một nhóm tấn công cụ thể.
- Yếu tố **Tactics** mô tả các mục tiêu chiến lược và khái niệm vận hành cấp cao, trả lời cho câu hỏi "tại sao" kẻ tấn công lại thực hiện hành động đó.
- Các phương pháp cụ thể được sử dụng để đạt được mục tiêu chiến thuật được gọi là **Techniques**, cung cấp bức tranh tổng quan về "cách thức" thực hiện.
- Những hướng dẫn từng bước chi tiết và vi mô nhất để thực thi một kỹ thuật được định nghĩa là **Procedures**.

## Indicators of Compromise & The Pyramid of Pain

![image.png](image%201.png)

- Một **Indicator** trong phân tích **CTI** phải bao gồm cả dữ liệu kỹ thuật lẫn thông tin ngữ cảnh, giúp các nhà phòng thủ đánh giá chính xác mức độ nghiêm trọng thay vì chỉ nhìn vào các con số vô hồn.
- Các dấu vết kỹ thuật số hoặc **artifacts** trích xuất từ các cuộc xâm nhập được gọi là **Indicators of Compromise (IOCs)**, đóng vai trò như các "biển báo" giúp phát hiện sớm hoạt động độc hại.
- Mô hình **Pyramid of Pain** minh họa hệ thống phân cấp các chỉ báo lây nhiễm, thể hiện mức độ khó khăn đối với kẻ tấn công khi chúng buộc phải thay đổi chiến thuật do bị phát hiện.

![image.png](image%202.png)

- Nằm ở đáy tháp là **Hash Values** (dấu vân tay kỹ thuật số của tệp), đây là chỉ báo kém tin cậy nhất vì kẻ tấn công có thể dễ dàng thay đổi mã băm chỉ bằng cách thêm hoặc bớt một byte dữ liệu.
- Các **IP Addresses** cũng là nhóm chỉ báo dễ bị qua mặt do kẻ tấn công thường che giấu IP thật thông qua kỹ thuật spoofing, VPN, proxy hoặc mạng TOR.
- Việc chặn **Domain Names** gây khó khăn hơn một chút, nhưng tin tặc vẫn có thể tạo hàng loạt miền ngẫu nhiên qua thuật toán DGA hoặc dùng Dynamic DNS để né tránh.
- Các dấu vết lưu lại trên hạ tầng (như mẫu lưu lượng, header gói tin) được gọi là **Network Artifacts**, trong khi các thay đổi trên máy chủ (như registry, tiến trình ngầm) được gọi là **Host Artifacts**; cả hai đều khiến kẻ tấn công rất khó che giấu mà không làm hỏng chiến dịch của chúng.
- Nhóm **Tools** bao gồm các phần mềm, mã độc hoặc framework C2 mà kẻ tấn công sử dụng; việc phát hiện công cụ buộc chúng phải tự viết lại mã với chi phí cao.
- Đỉnh tháp là **TTPs**, đây là những chỉ báo có giá trị nhất và khiến kẻ tấn công tốn nhiều chi phí, công sức nhất để thay đổi toàn bộ phương thức hoạt động nếu bị bóc trần.

## The Diamond Model of Intrusion Analysis

![image.png](image%203.png)

- Mô hình **Diamond Model** cung cấp một phương pháp tiếp cận có cấu trúc để phân tích một cuộc xâm nhập, bao gồm 4 đỉnh có mối liên hệ tương tác hai chiều với nhau.
- Đỉnh **Adversary** đại diện cho cá nhân hoặc tổ chức đứng sau cuộc tấn công, yêu cầu người phòng thủ phải hiểu rõ năng lực và động cơ của chúng.
- Đỉnh **Capability** bao hàm toàn bộ công cụ, phần mềm độc hại và các **TTPs** mà kẻ tấn công sử dụng để thực hiện việc xâm nhập.
- Đỉnh **Infrastructure** đại diện cho các tài nguyên vật lý và ảo (như máy chủ, tên miền, mạng botnet) được dùng để phát tán mã độc hoặc kiểm soát hệ thống từ xa.
- Đỉnh **Victim** chính là mục tiêu bị nhắm đến, đòi hỏi tổ chức phải tự đánh giá lại các lỗ hổng đang tồn tại và giá trị tài sản cốt lõi.
- So với Cyber Kill Chain vốn chỉ tập trung vào các giai đoạn tấn công theo tuyến tính, **Diamond Model** cung cấp góc nhìn toàn diện hơn về hệ sinh thái xâm nhập và các mối liên kết tương tác chặt chẽ.
- Trong thực tế, khi phân tích một chiến dịch phishing phát tán trojan ngân hàng, tổ chức tài chính chính là **Victim**, nhóm tội phạm là **Adversary**, email lừa đảo đóng vai trò **Capability**, và mạng botnet trung gian chính là **Infrastructure**.

# Threat Intelligence Fundamentals

## Cyber Threat Intelligence Definition

- Mục tiêu cốt lõi của **Cyber Threat Intelligence (CTI)** là chuyển đổi chiến lược phòng thủ của tổ chức từ trạng thái thụ động sang chủ động dự báo, qua đó cung cấp thông tin tình báo thiết yếu cho **Security Operations Center (SOC)**.
- Thông tin tình báo chỉ thực sự mang lại giá trị khi đảm bảo tính **Relevance**, tránh lãng phí nguồn lực vào các rủi ro không ảnh hưởng đến hạ tầng hiện tại.
- Tốc độ truyền đạt thông tin hoặc **Timeliness** quyết định hiệu quả phòng thủ, bởi dữ liệu phân tích sẽ nhanh chóng mất giá trị khi kẻ tấn công thay đổi chiến thuật hoặc lỗ hổng đã được vá.
- Mọi dữ liệu phân tích phải tạo ra **Actionability**, tức là cung cấp các chỉ dẫn hành động rõ ràng và thực tiễn cho đội ngũ phòng thủ mạng thay vì những thông tin chung chung.
- Trước khi phân phối, tình báo phải được kiểm chứng nghiêm ngặt về tính **Accuracy** kèm theo các mức độ tin cậy cụ thể nhằm tránh việc báo động giả hoặc lãng phí tài nguyên vào các chiến thuật sai lệch.
- Sự hội tụ của bốn yếu tố trên giúp tổ chức thấu hiểu các chiến dịch tấn công, vạch trần các **TTPs** của kẻ thù và hỗ trợ ban lãnh đạo đưa ra các quyết định kinh doanh chiến lược hiệu quả.

## The Difference Between Threat Intelligence & Threat Hunting

- Hoạt động **Threat Intelligence** mang tính dự báo, tập trung vào việc phán đoán trước vị trí, thời điểm, chiến lược tác chiến và mục tiêu cuối cùng của kẻ tấn công.
- Ngược lại, **Threat Hunting** kết hợp cả **Reactive and Proactive**, thường được kích hoạt bởi một dấu hiệu khả nghi nhằm xác định xem kẻ tấn công đang ẩn nấp hay đã từng hiện diện trong mạng.
- Hai lĩnh vực này có mối quan hệ cộng sinh chặt chẽ; hồ sơ tình báo giúp định hướng các chiến dịch săn lùng, trong khi kết quả từ việc săn lùng cung cấp dữ liệu thực tế để tinh chỉnh lại độ chính xác của các báo cáo tình báo.

## Criteria Of Cyber Threat Intelligence & Intelligence Types

- Việc thu thập và phân tích **CTI** chất lượng cao giúp ban lãnh đạo thấu hiểu rủi ro, xây dựng kế hoạch ứng phó sự cố và được phân loại thành ba cấp độ giao thoa chặt chẽ với nhau.
- **Strategic Intelligence** được thiết kế riêng cho đội ngũ lãnh đạo cấp cao (C-suite), tập trung giải đáp câu hỏi **Who?** và **Why?** bằng cách liên kết tình báo với rủi ro doanh nghiệp và vạch ra xu hướng tấn công dài hạn.
- **Operational Intelligence** phục vụ chủ yếu cho quản lý cấp trung, đi sâu vào việc giải đáp **How?** và **Where?** thông qua các phân tích chi tiết về chiến dịch tấn công và phương thức hoạt động của kẻ thù.
- **Tactical Intelligence** cung cấp dữ liệu kỹ thuật tức thời như các **Indicators of Compromise (IOCs)** cho đội ngũ phòng thủ mạng để nhanh chóng phát hiện và ngăn chặn các mối đe dọa kỹ thuật cụ thể.
- Ba loại hình tình báo này không hoạt động độc lập; thông tin chiến thuật luôn góp phần định hình bức tranh hoạt động chiến dịch và ngược lại, tạo thành một hệ sinh thái tình báo toàn diện.

## How To Go Through A Tactical Threat Intelligence Report

- Bước đầu tiên là **Comprehending the Report's Scope and Narrative** để nắm bắt bối cảnh vĩ mô, mục tiêu của kẻ tấn công và đánh giá mức độ liên quan của chiến dịch đối với ngành nghề của tổ chức.
- Tiếp theo là **Spotting and Classifying the IOCs** thành các nhóm riêng biệt như Network-based (IP, domain), Host-based (hash, registry) và Email-based để dễ dàng hệ thống hóa và triển khai biện pháp phòng thủ.
- Việc **Comprehending the Attack's Lifecycle** yêu cầu ánh xạ các TTPs trong báo cáo vào khung **MITRE ATT&CK** nhằm dự báo chính xác đường đi nước bước của kẻ tấn công từ giai đoạn xâm nhập đến khi chiếm quyền điều khiển.
- Giai đoạn **Analysis and Validation of IOCs** bắt buộc phải đối chiếu chéo dữ liệu với các nguồn uy tín (như VirusTotal) để loại bỏ các chỉ báo đã lỗi thời và giảm thiểu tối đa tỷ lệ cảnh báo giả (**false positive rate**).
- Sau khi xác thực, quá trình **Incorporating the IOCs** sẽ tích hợp dữ liệu vào các hệ thống tường lửa, **EDR** và **IDS/IPS**, đồng thời phải đánh giá kỹ tác động đến vận hành doanh nghiệp trước khi thiết lập lệnh chặn tự động.
- Dựa trên báo cáo, đội ngũ sẽ tiến hành **Proactive Threat Hunting** không chỉ để rà soát các bộ IOCs tĩnh mà còn mở rộng việc tìm kiếm các dấu hiệu bất thường dựa trên TTPs rộng hơn như việc lạm dụng PowerShell.
- Chu trình này khép lại bằng việc **Continuous Monitoring and Learning**, liên tục theo dõi hệ thống, điều chỉnh bộ quy tắc phát hiện và tích cực đóng góp các IOCs mới phát hiện cho cộng đồng thông qua các nền tảng tình báo chuyên ngành.